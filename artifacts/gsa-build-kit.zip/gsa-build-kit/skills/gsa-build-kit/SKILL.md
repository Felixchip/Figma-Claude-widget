---
name: gsa-build-kit
description: Design, build or render CMC Markets interfaces using the GSA design system. Use this whenever the user asks to design a screen, build iOS/SwiftUI UI, or generate a mockup or image for CMC Markets, so the work uses the real GSA components, tokens and rules instead of invented ones.
---

# GSA Build Kit

Use this skill for any CMC Markets interface work: designing a screen, writing
SwiftUI, or producing a mockup image.

## Start here, every time

Before doing anything else, load the rules and the library:

1. Call `list_rules` and follow it. It is mandatory and overrides your defaults.
   It is deliberately short: the non-negotiables, the three routes, the System
   Foundation, the Render Guide, and the index of every component that exists.
2. Call `get_component_rule` for **each component you are about to use** — it has
   the anatomy, variants, states and do/don't guidance that `list_rules` only
   indexes.
3. Call `get_figma_library` and `list_figma_components` to see the real components.
4. Call `get_figma_tokens` for the colour, spacing, radius and type values.
5. Call `list_components` and `get_component` for the SwiftUI implementations.
6. Call `list_specs` / `get_spec` if the user refers to a published product spec.

Never invent a component, token, prop, colour or spacing value. If something you
need does not exist in the library, stop and ask the user.

## The two ways this usually goes wrong

- **Designing in Figma:** drawing rectangles, frames or text as stand-ins for
  components that exist. Place **instances** of the GSA library components
  instead. Check the component list first.
- **Generating an image:** drawing components from scratch. Fetch
  `get_component_render` for **every** element before you compose. If you have
  not fetched its image, you do not know what it looks like.

## Choose the route

Ask which one the user wants when it is not clear:

1. **Design in Figma.** The user wants the design created inside their own Figma
   file ("design this in Figma", "create it in my Figma file"). Author it with
   **Figma's official MCP**, a separate connection using the user's own Figma
   account. This route **does** need a Figma file or frame link, so ask for one
   if the user has not given it. Use this Build Kit for the components, tokens
   and rules to build with.
2. **Build.** The user wants code. Write SwiftUI that reuses the real components
   from the repo. Do not hand-roll a replacement for a component that exists.
3. **Render.** The user wants an image or mockup, or has no Figma connection.
   Call `get_component_render` for each component you need. It returns the real
   rendered image and accepts a `theme` (for example `"Light"`); to target a
   specific variation use `"Component / Variant"`, for example
   `"Button / Enabled=false"`. Then compose the mockup yourself using the
   palette, spacing and type tokens. **Do not ask for a Figma link on this route.**

## Finish by submitting the visual

Once the user has seen the result, call **`submit_output`** and **send the visual
first** — the image or screenshot is the thing that gets reviewed.

- `image_base64` (with or without a `data:` prefix), or `image_url` for a public
  link. For a Figma design, send a screenshot or export of the frame.
- `kind`: `image`, `figma` or `code`.
- `components`: the GSA components visible in the output.
- `notes`: anything that felt wrong, was hard, or that you had to work around —
  a missing component, a value you couldn't find, a place you had to improvise.
- `summary` / `prompt`: brief context only. Keep the text short.

Be honest in `notes`. Reporting a gap is more useful than hiding it, and it never
changes the user's design or code.

## Guardrails

- Use only the GSA components. Never create, wrap or substitute one.
- Verify before you assert: components, props and tokens must come from the tools.
- One primary action per screen, spaced with the token scale, aligned deliberately.
- Design the empty, loading and error states, or ask the user how they should look.
- When in doubt, ask. Do not guess.
